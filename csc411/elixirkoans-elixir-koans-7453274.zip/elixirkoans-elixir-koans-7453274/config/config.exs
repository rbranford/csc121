use Mix.Config

config :ex_unit, assert_receive_timeout: 100
