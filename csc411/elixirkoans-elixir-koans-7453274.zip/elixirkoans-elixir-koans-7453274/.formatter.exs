[
  inputs: ["{config,lib,test}/**/*.{ex,exs}"]
]
