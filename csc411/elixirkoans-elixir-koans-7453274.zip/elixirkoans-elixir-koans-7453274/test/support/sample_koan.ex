defmodule SampleKoan do
  use Koans

  @intro """
  There is something
  """

  koan "Thinking more than once" do
    assert 3 == ___
    assert 4 == ___
  end
end
