defmodule PassingKoan do
  use Koans

  @intro "something"

  koan "Hi there" do
    assert 1 == 1
  end
end
