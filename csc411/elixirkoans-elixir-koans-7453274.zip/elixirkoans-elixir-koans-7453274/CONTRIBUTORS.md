"Thank you!" to all the contributors (alphabetical order):

*  Alex
*  Fabien Townsend
*  Felipe Seré
*  gemcfadyen
*  Jay Hayes
*  kamidev
*  Mahmut Surekci
*  Makis Otman
*  Nathan Walker
*  Rabea Gleissner
*  Ria Cataquian
*  Simone D'Amico
*  snikolau
*  Stephen Rufle
*  Trung Lê
*  Uku Taht
*  Zander Mackie
